<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
</head>
<?php
    include('config.php');
?>
<body>
    <header>
        <h1>Welcome to My Homepage</h1>
    </header>
    <main>
        <img src="images/gmbr.jpg" height="800" width="500" title="Zuhair Isyraq Bin Zairil B22EC3015">
    </main>
<button ><a style="text-decoration:none" href="logout.php">Logout</a></button>
</body>
</html>